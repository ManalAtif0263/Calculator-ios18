package com.example.assignment1;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.PopupMenu;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button ac, signchange, percent, div, seven, eight, nine, point, zero, one, two, three, four, five, six, equal, add, min, mul, opt;
    Button btnX2, btnX3, btnBopen, btnBclose, btnLog, btnXx, btnEx, btn10X, btnX, btnLn, btnS2, btnS3, btnSx, btn1Dx, btnTan, btnCos, btnSin, btnS_h, btnC_h, btnT_h;
    Button btnmr , btnMc,btnMSUB,btnMSUM,btnPi,btnRad,btnR_h;
    EditText result;
    double memoryValue = 0.0;
    float value, value1,ans;
    double base = 0;
    boolean adding, subtract, multiply, division, percentage;
    boolean log, squareroot, cuberoot, factorial, square, cube, oneOverX, isExponent,isresult;
    boolean newval = false;
    String str;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        int orientation = getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setupLandscapeButtons();
        } /*else {
            setupPortraitButtons();
        }*/
        result = findViewById(R.id.result);

        ac = findViewById(R.id.ac);
        signchange = findViewById(R.id.signchange);
        percent = findViewById(R.id.percent);
        div = findViewById(R.id.div);
        seven = findViewById(R.id.seven);
        eight = findViewById(R.id.eight);
        nine = findViewById(R.id.nine);
        zero = findViewById(R.id.zero);
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);
        five = findViewById(R.id.five);
        six = findViewById(R.id.six);
        equal = findViewById(R.id.equal);
        add = findViewById(R.id.add);
        min = findViewById(R.id.min);
        mul = findViewById(R.id.mul);
        opt = findViewById(R.id.opt);
        point = findViewById(R.id.point);

        ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                result.setText("0");

            }
        });

        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (newval)
                {
                    result.setText("0");
                    newval = false;
                }
                else
                {
                    result.setText(result.getText() + "0");
                }
            }
        });

        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (newval)
                {
                    result.setText("1");
                    newval = false;
                }
                else
                {
                    str = null;
                    str = result.getText() + "";
                    if (str.equals("0"))
                    {
                        result.setText("1");
                    }
                    else
                    {
                        result.setText(str + "1");
                    }

                }
            }
        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (newval)
                {
                    result.setText("2");
                    newval = false;
                }
                else
                {
                    str = null;
                    str = result.getText() + "";
                    if (str.equals("0"))
                    {
                        result.setText("2");
                    }
                    else
                    {
                        result.setText(str + "2");
                    }

                }
            }
        });

        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (newval)
                {
                    result.setText("3");
                    newval = false;
                }
                else
                {
                    str = null;
                    str = result.getText() + "";
                    if (str.equals("0"))
                    {
                        result.setText("3");
                    }
                    else
                    {
                        result.setText(str + "3");
                    }

                }
            }
        });

        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (newval)
                {
                    result.setText("4");
                    newval = false;
                }
                else
                {
                    str = null;
                    str = result.getText() + "";
                    if (str.equals("0"))
                    {
                        result.setText("4");
                    }
                    else
                    {
                        result.setText(str + "4");
                    }

                }
            }
        });

        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (newval)
                {
                    result.setText("5");
                    newval = false;
                }
                else
                {
                    str = null;
                    str = result.getText() + "";
                    if (str.equals("0"))
                    {
                        result.setText("5");
                    }
                    else
                    {
                        result.setText(str + "5");
                    }

                }
            }
        });
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (newval)
                {
                    result.setText("6");
                    newval = false;
                }
                else
                {
                    str = null;
                    str = result.getText() + "";
                    if (str.equals("0"))
                    {
                        result.setText("6");
                    }
                    else
                    {
                        result.setText(str + "6");
                    }

                }
            }
        });
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (newval)
                {
                    result.setText("7");
                    newval = false;
                }
                else
                {
                    str = null;
                    str = result.getText() + "";
                    if (str.equals("0"))
                    {
                        result.setText("7");
                    }
                    else
                    {
                        result.setText(str + "7");
                    }

                }
            }
        });
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (newval)
                {
                    result.setText("8");
                    newval = false;
                }
                else
                {
                    str = null;
                    str = result.getText() + "";
                    if (str.equals("0"))
                    {
                        result.setText("8");
                    }
                    else
                    {
                        result.setText(str + "8");
                    }

                }
            }
        });
        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (newval)
                {
                    result.setText("9");
                    newval = false;
                }
                else
                {
                    str = null;
                    str = result.getText() + "";
                    if (str.equals("0"))
                    {
                        result.setText("9");
                    }
                    else
                    {
                        result.setText(str + "9");
                    }

                }
            }
        });

        point.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str = null;
                str = result.getText() + "";

                if (!str.contains("."))
                {
                    result.setText(str + ".");
                }

            }
        });


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = Float.parseFloat(result.getText() + "");
                adding = true;
                newval = true;
            }
        });
        min.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = Float.parseFloat(result.getText() + "");
                subtract = true;
                newval = true;
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = Float.parseFloat(result.getText() + "");
                division = true;
                newval = true;
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = Float.parseFloat(result.getText() + "");
                multiply = true;
                newval = true;
            }
        });
        percent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = Float.parseFloat(result.getText() + "");
                percentage = true;
                newval = true;
            }
        });
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isExponent) {
                    double power = Double.parseDouble(result.getText()+"");
                    double r = Math.pow(base, power);
                    result.setText(String.valueOf(r));
                    isExponent = false;
                    isresult = true;
                    return;
                }


                    if (oneOverX == true)
                    {
                        value1 = Float.parseFloat(result.getText() + "");

                        result.setText((1 / value1) + "");
                        oneOverX = false;
                    }
                    if (squareroot == true)
                    {
                        value1 = Float.parseFloat(result.getText() + "");
                        double r = Math.sqrt(value1);
                        result.setText((r)+"");
                        squareroot = false;

                    }
                    if (cuberoot == true)
                    {
                        value1 = Float.parseFloat(result.getText() + "");
                        double r = Math.cbrt(value1);
                        result.setText((r)+"");
                        cuberoot = false;


                    }
                    if (square == true)
                    {
                        value1 = Float.parseFloat(result.getText() + "");
                        result.setText((value1 * value1) + "");
                        square = false;
                    }
                    if (cube == true)
                    {
                        value1 = Float.parseFloat(result.getText() + "");
                        result.setText((value1* value1 * value1) + "");
                        cube = false;
                    }
                    if (log == true)
                    {

                        result.setText((ans)+"");
                        log = false;
                    }
                    if (factorial == true) {
                        value1 = Float.parseFloat(result.getText() + "");

                        int number = (int)value1;
                        int ans = 1;
                        for (int i = 1; i <= number; i++) {
                            ans *= i;
                        }

                        result.setText(ans + "");
                        factorial = false;
                    }
                    value1 = Float.parseFloat(result.getText() + "");

                    if (adding == true)
                    {
                        result.setText((value + value1) + "");
                        adding = false;
                    }
                    else if (subtract == true)
                    {
                        result.setText((value - value1) + "");
                        subtract = false;
                    }
                    else if (multiply == true)
                    {
                        result.setText((value * value1) + "");
                        multiply = false;
                    }
                    else if (division == true)
                    {
                        if (value1 != 0)
                        {
                            result.setText((value / value1) + "");
                        }
                        else
                        {
                            result.setText("Math Error");
                        }
                        division = false;
                    }
                    else if (percentage)
                    {
                        result.setText((value % value1) + "");
                        percentage = false;
                    }

                }
            });

        opt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    PopupMenu popupMenu = new PopupMenu(MainActivity.this, opt);
                    popupMenu.getMenu().add("Basic");
                    popupMenu.getMenu().add("Scientific");
                    popupMenu.getMenu().add("Math Notes");
                    popupMenu.getMenu().add("Convert");


                    popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {

                            String selected = item.getTitle() + "";

                            return true;
                        }
                    });


                    popupMenu.show();
                }
            });

        signchange.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String current = result.getText() + "";

                    if (current != null)
                    {
                        value = Float.parseFloat(result.getText() + "");

                        value = -value;


                        result.setText(String.valueOf(value));
                    }
                }
            });

        }


    private void setupLandscapeButtons() {

        btnX2 = findViewById(R.id.btnX2);
        btnX3 = findViewById(R.id.btnX3);
        btnLog = findViewById(R.id.btnLog);
        btnXx = findViewById(R.id.btnXx);
        btnEx = findViewById(R.id.btnEx);
        btn10X = findViewById(R.id.btn10X);
        btnBopen = findViewById(R.id.btnBopen);
        btnBclose = findViewById(R.id.btnBclose);
        btnX = findViewById(R.id.btnX);
        btnLn = findViewById(R.id.btnLn);
        btnS2 = findViewById(R.id.btnS2);
        btnS3 = findViewById(R.id.btnS3);
        btnSx = findViewById(R.id.btnSx);
        btn1Dx = findViewById(R.id.btn1Dx);
        btnTan = findViewById(R.id.btnTan);
        btnCos = findViewById(R.id.btnCos);
        btnSin = findViewById(R.id.btnSin);
        btnT_h = findViewById(R.id.btnT_h);
        btnC_h = findViewById(R.id.btnC_h);
        btnS_h = findViewById(R.id.btnS_h);
        btnPi=findViewById(R.id.btnPi);
        btnRad=findViewById(R.id.btnRad);
        btnR_h=findViewById(R.id.btnR_h);
        btnmr=findViewById(R.id.btnmr);
        btnMc=findViewById(R.id.btnMc);
        btnMSUM=findViewById(R.id.btnMSUM);
        btnMSUB=findViewById(R.id.btnMSUB);


        btnBopen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str = result.getText() + "";
                if (str.equals("0")) {
                    result.setText("(");
                }
                else {

                    result.setText(str + "(");
                }
            }
        });

        btnBclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str = result.getText() + "";
                result.setText(str + ")");
            }
        });


        btnX2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                square = true;
                equal.performClick();
            }
        });


        btnX3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cube = true;
                equal.performClick();
            }
        });


        btnLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double input = Double.parseDouble(result.getText() + "");
                    double r = Math.log10(input);
                    result.setText(String.valueOf(r));
                    isresult = true;
                }
                catch (Exception e) {
                    result.setText("Syntax Error");
                }
            }
        });


        btnXx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                base = Double.parseDouble(result.getText()+"");
                result.setText("");
                isExponent = true;
            }
        });


        btnEx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double input = Double.parseDouble(result.getText()+"");
                    double r = Math.exp(input);
                    result.setText(String.valueOf(r));
                    isresult = true;
                }
                catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });


        btn10X.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double input = Double.parseDouble(result.getText().toString());
                    double r = Math.pow(10, input);
                    result.setText(String.valueOf(r));
                    isresult = true;
                }
                catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });

        btnX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                factorial = true;
                equal.performClick();
            }
        });

        btnLn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double input = Double.parseDouble(result.getText() + "");
                    double r = Math.log(input);
                    result.setText(String.valueOf(r));
                    isresult = true;
                }
                catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });

        btnS2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                squareroot = true;
                equal.performClick();
            }
        });


        btnS3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cuberoot = true;
                equal.performClick();
            }
        });

        btn1Dx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                oneOverX = true;
                equal.performClick();
            }
        });

        btnTan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double finput = Double.parseDouble(result.getText() + "");
                    double input = Math.toRadians(finput);
                    double r = Math.tan(input);
                    result.setText(String.valueOf(r));
                    isresult = true;
                }
                catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });

        btnCos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double finput = Double.parseDouble(result.getText() + "");
                    double input = Math.toRadians(finput);
                    double r = Math.cos(input);
                    result.setText(String.valueOf(r));
                    isresult = true;
                }
                catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });

        btnSin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double finput = Double.parseDouble(result.getText() + "");
                    double input = Math.toRadians(finput);
                    double r = Math.sin(input);
                    result.setText(String.valueOf(r));
                    isresult = true;
                }
                catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });

        btnT_h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double finput = Double.parseDouble(result.getText() + "");
                    double input = Math.toRadians(finput);
                    double r = Math.tanh(input);
                    result.setText(String.valueOf(r));
                    isresult = true;
                }
                catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });

        btnC_h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double finput = Double.parseDouble(result.getText() + "");
                    double input = Math.toRadians(finput);
                    double r = Math.cosh(input);
                    result.setText(String.valueOf(r));
                    isresult = true;
                }
                catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });

        btnS_h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double finput = Double.parseDouble(result.getText() + "");
                    double input = Math.toRadians(finput);
                    double r = Math.sinh(input);
                    result.setText(String.valueOf(r));
                    isresult = true;
                }
                catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });
        btnPi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {

                    String current = result.getText()+"";


                    if (current.equals("")) {
                        result.setText(String.valueOf(Math.PI));
                    } else {
                        result.setText(current + String.valueOf(Math.PI));
                    }

                    isresult = false;
                } catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });

        btnRad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double input = Double.parseDouble(result.getText() + "");
                    double results = Math.toRadians(input);
                    result.setText(String.valueOf(results));
                    isresult = true;
                } catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });

        btnR_h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double input = Double.parseDouble(result.getText() + "");
                    double results = Math.toDegrees(input);
                    result.setText(String.valueOf(results));
                    isresult = true;
                } catch (Exception e) {
                    result.setText("Math Error");
                }
            }
        });
        btnmr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                result.setText(String.valueOf(memoryValue));
            }
        });

        btnMSUM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double currentValue = Double.parseDouble(result.getText().toString());
                memoryValue += currentValue;
            }
        });

        btnMSUB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double currentValue = Double.parseDouble(result.getText().toString());
                memoryValue -= currentValue;
            }
        });

        btnMc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                memoryValue = 0.0;
            }
        });
    }
    }